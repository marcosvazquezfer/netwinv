Welcome to configparser documentation!
======================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: configparser
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

